#!/usr/bin/env bash
# build_inner.sh — se ejecuta DENTRO del contenedor Ubuntu (proot-distro).
# No lo llames a mano; lo invoca build_termux.sh.
set -e

echo ">>> Actualizando Ubuntu e instalando dependencias de compilacion..."
apt-get update -y
DEBIAN_FRONTEND=noninteractive apt-get install -y \
    openjdk-17-jdk-headless python3-pip python3-venv git zip unzip \
    autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev \
    libtinfo5 cmake build-essential libffi-dev libssl-dev automake gettext \
    ccache wget curl

echo ">>> Instalando buildozer y cython..."
pip3 install --upgrade pip
pip3 install buildozer "cython==0.29.36"

export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH

cd /root/cerberus

echo ">>> Compilando APK (la 1a vez descarga SDK+NDK ~4 GB y tarda ~1-2 h)..."
buildozer -v android debug

echo ">>> APK generado:"
ls -la bin/*.apk
