# Cerberus IA v3 — KivyMD (Android APK / Escritorio)

Asistente de IA creado por **CarlosArt** (`carlosrafaelsart@gmail.com`).
Reescrito en **Kivy/KivyMD** para poder compilarse a APK nativo de Android.

## Novedades v3 (frente a v2)
- **Multiples conversaciones reales** (cajon lateral, crear, seleccionar, eliminar). En v2 solo habia un historial plano que se borraba todo.
- **Modo ONLINE seguro**: token de autenticacion (Bearer), validacion de URL, aviso si usas HTTP sin cifrar, errores diferenciados (HTTP 4xx/5xx, sin conexion, JSON invalido).
- **Indicador "Cerberus esta escribiendo..."** y bloqueo de entrada mientras llega la respuesta (evita respuestas desordenadas).
- **Escritura atomica** de `config.json` y `conversations.json` (no se corrompen si se cierra la app a medias).
- **Almacenamiento en directorio de usuario** (`user_data_dir`), compatible con Android (en v2 se escribia junto al ejecutable, que es de solo lectura en APK).
- Tema oscuro unificado, iconos Material (sin emojis), boton "Atras" de Android funcional.
- Pantalla de **Ajustes** (endpoint, token, modo online) y **Acerca de**.

## Archivos
| Archivo | Que es |
|---|---|
| `main.py` | La aplicacion (punto de entrada) |
| `buildozer.spec` | Configuracion de compilacion a APK |
| `build_termux.sh` + `build_inner.sh` | Compilar el APK **desde Termux** |
| `.github/workflows/build.yml` | Compilar el APK en GitHub Actions (alternativa mas fiable) |
| `icon.png` / `presplash.png` | Icono y pantalla de carga |
| `requirements.txt` | Dependencias para escritorio |
| `test_ui.py` | Pruebas automaticas de interfaz (headless) |

## Probar en escritorio
```bash
pip install -r requirements.txt
python main.py
```

## Compilar APK desde Termux (Android)
```bash
# 1. Copia esta carpeta a ~/cerberus_v3 en el telefono
# 2. En Termux:
bash ~/cerberus_v3/build_termux.sh
```
Usa `proot-distro` (Ubuntu dentro de Termux). La primera compilacion descarga
SDK+NDK (~4 GB) y tarda **1-2 horas**. Necesita ~6 GB libres.
El APK queda en `~/cerberus_v3/bin/cerberus-ia-3.0-arm64-v8a-debug.apk`.

> Consejo: si el build de Termux falla por poca RAM/almacenamiento, usa
> **GitHub Actions** (sube esta carpeta a un repo y ejecuta el workflow
> "Build APK") — te descargas el APK directamente desde GitHub, mucho mas rapido.

## Modo ONLINE (servidor de IA)
Configura en Ajustes:
- **URL del servidor**: endpoint que reciba `POST {"message": "..."}` y devuelva `{"response": "..."}`.
- **Token**: opcional, se envia como cabecera `Authorization: Bearer <token>`.

## Firma para lanzamiento (opcional)
El APK generado es de debug. Para distribuirlo:
```bash
keytool -genkey -v -keystore cerberus.keystore -alias cerberus -keyalg RSA -keysize 2048 -validity 10000
buildozer android release
```
