# -*- coding: utf-8 -*-
"""
Cerberus IA v3 — versión KivyMD (Android APK / escritorio)
Autor: CarlosArt
Mejoras v3:
  - Multiples conversaciones (historial real por chat).
  - Modo ONLINE con token de autenticacion (Bearer) y validacion de endpoint.
  - Indicador de "escribiendo..." y bloqueo de entrada durante la peticion.
  - Escritura atomica de JSON (evita corrupcion).
  - Almacenamiento en directorio de usuario (compatible con Android).
  - Tema oscuro unificado, sin emojis (iconos Material).
  - Pantalla de Ajustes (endpoint, token, modo online) y Acerca de.
"""

import json
import os
import threading
import urllib.request
import urllib.error
from datetime import datetime
from uuid import uuid4

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView

from kivymd.app import MDApp
from kivymd.toast import toast
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.button import MDFlatButton, MDIconButton, MDRaisedButton
from kivymd.uix.card import MDCard
from kivymd.uix.dialog import MDDialog
from kivymd.uix.label import MDLabel
from kivymd.uix.list import (
    MDList,
    OneLineAvatarIconListItem,
    IconRightWidget,
    OneLineListItem,
)
from kivymd.uix.navigationdrawer import MDNavigationDrawer, MDNavigationLayout
from kivymd.uix.screen import MDScreen
from kivymd.uix.screenmanager import MDScreenManager
from kivymd.uix.selectioncontrol import MDSwitch
from kivymd.uix.textfield import MDTextField
from kivymd.uix.toolbar import MDTopAppBar

APP_NAME = "Cerberus IA"
AUTHOR = "CarlosArt"
EMAIL = "carlosrafaelsart@gmail.com"
VERSION = "3.0"

DEFAULT_CONFIG = {
    "online_mode": False,
    "online_endpoint": "",
    "api_token": "",
}

# ---------------------------------------------------------------------------
# Persistencia (lectura / escritura atomica)
# ---------------------------------------------------------------------------

def data_dir():
    """Directorio de datos escribible (Android: user_data_dir; escritorio: ~/.cerberus_ia)."""
    app = App.get_running_app()
    if app is not None:
        return app.user_data_dir
    return os.path.join(os.path.expanduser("~"), ".cerberus_ia")


def _path(name):
    d = data_dir()
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, name)


def load_json(filename, default):
    try:
        with open(_path(filename), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return json.loads(json.dumps(default))  # copia profunda simple


def save_json_atomic(filename, data):
    """Escribe en .tmp y renombra: evita corrupcion si se cierra la app a medias."""
    path = _path(filename)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


# ---------------------------------------------------------------------------
# Motor de respuestas
# ---------------------------------------------------------------------------

def local_ai(message):
    m = message.lower().strip()
    if not m:
        return "Escribe algo y Cerberus te respondera."
    if any(x in m for x in ("hola", "buenas", "saludos", "hey")):
        return "Hola. Soy Cerberus IA, tu asistente creado por CarlosArt."
    if "quien eres" in m or "quien eres" in m.replace("é", "e"):
        return "Soy Cerberus IA, un asistente de inteligencia artificial creado por CarlosArt."
    if "autor" in m or "creador" in m or "quien te creo" in m:
        return "Mi autor es %s. Contacto: %s" % (AUTHOR, EMAIL)
    if "hora" in m:
        return "La hora del dispositivo es %s." % datetime.now().strftime("%H:%M:%S")
    if "fecha" in m:
        return "La fecha del dispositivo es %s." % datetime.now().strftime("%d/%m/%Y")
    if "ayuda" in m or "help" in m:
        return ("Estoy en modo OFFLINE. Puedo responder a: hola, quien eres, "
                "autor, hora, fecha o ayuda. Para respuestas avanzadas activa "
                "el modo ONLINE en Ajustes y configura tu servidor de IA.")
    return ("Estoy en modo OFFLINE y no entiendo ese mensaje. Prueba con: "
            "hola, ayuda, hora, fecha o quien eres. O activa el modo ONLINE.")


def online_ai(message, endpoint, token, timeout=20):
    """POST a {endpoint} con {message: ...} y cabecera Authorization Bearer (si hay token).
    Devuelve (respuesta, None) o (None, mensaje_de_error)."""
    if not endpoint:
        return None, "No hay servidor configurado. Ve a Ajustes."
    payload = json.dumps({"message": message}, ensure_ascii=False).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    req = urllib.request.Request(endpoint, data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = json.loads(r.read().decode("utf-8"))
        resp = body.get("response")
        if not resp:
            return None, "El servidor respondio, pero sin el campo 'response'."
        return resp, None
    except urllib.error.HTTPError as e:
        return None, "Error del servidor (HTTP %s)." % e.code
    except urllib.error.URLError as e:
        return None, "No pude conectar con el servidor. (%s)" % e.reason
    except json.JSONDecodeError:
        return None, "La respuesta del servidor no es JSON valido."
    except Exception as e:
        return None, "Error inesperado: %s" % e.__class__.__name__


# ---------------------------------------------------------------------------
# Burbujas de chat
# ---------------------------------------------------------------------------

class ChatBubble(MDCard):
    def __init__(self, text, from_user, **kwargs):
        super().__init__(**kwargs)
        self.orientation = "vertical"
        self.adaptive_height = True
        self.size_hint_x = 0.82
        self.radius = [dp(16)]
        self.padding = [dp(12), dp(10), dp(12), dp(10)]
        self.pos_hint = {"right": 1} if from_user else {"x": 0}
        app = App.get_running_app()
        if from_user:
            self.md_bg_color = app.theme_cls.primary_color
            text_color = (1, 1, 1, 1)
        else:
            self.md_bg_color = (0.17, 0.19, 0.24, 1)
            text_color = (0.95, 0.95, 0.97, 1)
        label = MDLabel(
            text=text,
            theme_text_color="Custom",
            text_color=text_color,
            adaptive_height=True,
            font_style="Body1",
        )
        self.add_widget(label)


# ---------------------------------------------------------------------------
# Pantalla de chat
# ---------------------------------------------------------------------------

class ChatScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.typing_bubble = None
        self.waiting = False

        root_layout = MDBoxLayout(orientation="vertical")

        # Barra superior
        self.toolbar = MDTopAppBar(
            title="Cerberus IA",
            left_action_items=[["menu", lambda x: self.open_drawer()]],
            right_action_items=[
                ["wifi-off" if not App.get_running_app().config.get("online_mode") else "wifi",
                 lambda x: self.toggle_mode()],
                ["cog", lambda x: setattr(self.manager, "current", "settings")],
            ],
            elevation=2,
        )
        root_layout.add_widget(self.toolbar)

        # Area de mensajes
        self.scroll = ScrollView(do_scroll_x=False)
        self.messages = MDBoxLayout(
            orientation="vertical",
            size_hint_y=None,
            spacing=dp(8),
            padding=[dp(12), dp(12), dp(12), dp(12)],
        )
        self.messages.bind(minimum_height=self.messages.setter("height"))
        self.scroll.add_widget(self.messages)
        root_layout.add_widget(self.scroll)

        # Barra inferior: entrada + enviar
        bottom = MDBoxLayout(
            orientation="horizontal",
            size_hint_y=None,
            height=dp(64),
            padding=[dp(8), dp(6), dp(8), dp(10)],
            spacing=dp(6),
        )
        self.input = MDTextField(
            hint_text="Escribe un mensaje...",
            mode="round",
            multiline=False,
            size_hint_x=0.88,
        )
        self.input.bind(on_text_validate=lambda x: self.send())
        bottom.add_widget(self.input)
        self.send_btn = MDIconButton(
            icon="send",
            theme_icon_color="Custom",
            icon_color=App.get_running_app().theme_cls.primary_color,
            on_release=lambda x: self.send(),
        )
        bottom.add_widget(self.send_btn)
        root_layout.add_widget(bottom)

        self.add_widget(root_layout)

    # -- utilidades -------------------------------------------------------
    @property
    def app(self):
        return App.get_running_app()

    def open_drawer(self):
        self.app.nav_drawer.set_state("open")

    def refresh_toolbar(self):
        online = self.app.config.get("online_mode")
        self.toolbar.right_action_items = [
            ["wifi" if online else "wifi-off", lambda x: self.toggle_mode()],
            ["cog", lambda x: setattr(self.parent, "current", "settings")],
        ]
        self.toolbar.title = self.app.current_conversation().get("title", "Cerberus IA")

    def toggle_mode(self):
        self.app.config["online_mode"] = not self.app.config.get("online_mode", False)
        save_json_atomic("config.json", self.app.config)
        self.refresh_toolbar()
        mode = "ONLINE" if self.app.config["online_mode"] else "OFFLINE"
        self.add_bubble("Modo %s activado." % mode, from_user=False, save=True)
        toast("Modo %s" % mode)

    def scroll_to_bottom(self, *args):
        Clock.schedule_once(lambda dt: setattr(self.scroll, "scroll_y", 0), 0.05)

    def add_bubble(self, text, from_user, save=True):
        bubble = ChatBubble(text, from_user)
        self.messages.add_widget(bubble)
        self.scroll_to_bottom()
        if save:
            conv = self.app.current_conversation()
            conv["messages"].append({
                "time": datetime.now().isoformat(timespec="seconds"),
                "sender": "Tu" if from_user else "Cerberus",
                "text": text,
            })
            # Titulo automatico con el primer mensaje del usuario
            if from_user and conv.get("title", "Nueva conversacion") == "Nueva conversacion":
                conv["title"] = text[:30] + ("..." if len(text) > 30 else "")
                self.toolbar.title = conv["title"]
            save_json_atomic("conversations.json", self.app.conversations)
        return bubble

    def render_conversation(self):
        self.messages.clear_widgets()
        conv = self.app.current_conversation()
        for msg in conv["messages"]:
            self.add_bubble(msg["text"], from_user=(msg["sender"] == "Tu"), save=False)
        if not conv["messages"]:
            self.add_bubble(
                "Hola. Soy Cerberus IA.\nAutor: %s\nCorreo: %s\n"
                "Puedes cambiar entre ONLINE y OFFLINE desde el icono de arriba."
                % (AUTHOR, EMAIL),
                from_user=False, save=False,
            )
        self.refresh_toolbar()

    # -- envio ------------------------------------------------------------
    def send(self):
        if self.waiting:
            return
        text = self.input.text.strip()
        if not text:
            return
        self.input.text = ""
        self.add_bubble(text, from_user=True)

        self.waiting = True
        self.input.disabled = True
        self.send_btn.disabled = True
        self.typing_bubble = self.add_bubble("Cerberus esta escribiendo...",
                                             from_user=False, save=False)

        threading.Thread(target=self._answer_thread, args=(text,), daemon=True).start()

    def _answer_thread(self, text):
        response = None
        if self.app.config.get("online_mode"):
            response, err = online_ai(
                text,
                self.app.config.get("online_endpoint", ""),
                self.app.config.get("api_token", ""),
            )
            if err:
                response = err + " (respondo en modo offline.)"
                offline = local_ai(text)
                if offline and "no entiendo" not in offline:
                    response += "\n" + offline
        if response is None:
            response = local_ai(text)
        Clock.schedule_once(lambda dt: self._deliver(response))

    def _deliver(self, response):
        if self.typing_bubble:
            self.messages.remove_widget(self.typing_bubble)
            self.typing_bubble = None
        self.waiting = False
        self.input.disabled = False
        self.send_btn.disabled = False
        self.add_bubble(response, from_user=False, save=True)


# ---------------------------------------------------------------------------
# Pantalla de ajustes
# ---------------------------------------------------------------------------

class SettingsScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        app = App.get_running_app()
        root = MDBoxLayout(orientation="vertical", spacing=dp(10), padding=dp(16))

        toolbar = MDTopAppBar(
            title="Ajustes",
            left_action_items=[["arrow-left", lambda x: self.go_back()]],
            elevation=2,
        )
        root.add_widget(toolbar)

        scroll = ScrollView()
        body = MDBoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(14),
                           padding=[dp(4), dp(8), dp(4), dp(8)])
        body.bind(minimum_height=body.setter("height"))

        self.endpoint = MDTextField(
            hint_text="URL del servidor de IA (https://...)",
            mode="rectangle",
            text=app.config.get("online_endpoint", ""),
        )
        body.add_widget(MDLabel(text="URL del servidor de IA:", adaptive_height=True))
        body.add_widget(self.endpoint)

        self.token = MDTextField(
            hint_text="Token de acceso (Bearer, opcional)",
            mode="rectangle",
            password=True,
            text=app.config.get("api_token", ""),
        )
        body.add_widget(MDLabel(text="Token de autenticacion:", adaptive_height=True))
        body.add_widget(self.token)

        # Switch modo online
        row = MDBoxLayout(orientation="horizontal", size_hint_y=None, height=dp(48),
                          spacing=dp(10))
        row.add_widget(MDLabel(text="Modo ONLINE:", adaptive_height=True,
                               pos_hint={"center_y": 0.5}))
        self.online_switch = MDSwitch(active=bool(app.config.get("online_mode", False)),
                                      pos_hint={"center_y": 0.5})
        row.add_widget(self.online_switch)
        body.add_widget(row)

        save_btn = MDRaisedButton(text="GUARDAR", on_release=lambda x: self.save())
        save_btn.pos_hint = {"center_x": 0.5}
        body.add_widget(save_btn)

        about_btn = MDFlatButton(text="Acerca de", on_release=lambda x: self.about())
        about_btn.pos_hint = {"center_x": 0.5}
        body.add_widget(about_btn)

        scroll.add_widget(body)
        root.add_widget(scroll)
        self.add_widget(root)

    def go_back(self):
        self.manager.current = "chat"

    def save(self):
        app = App.get_running_app()
        ep = self.endpoint.text.strip()
        if ep and not ep.startswith(("http://", "https://")):
            toast("La URL debe empezar por http:// o https://")
            return
        if ep.startswith("http://"):
            toast("Aviso: HTTP envia tus mensajes sin cifrar.")
        app.config["online_endpoint"] = ep
        app.config["api_token"] = self.token.text.strip()
        app.config["online_mode"] = bool(self.online_switch.active)
        save_json_atomic("config.json", app.config)
        toast("Configuracion guardada.")
        self.go_back()
        Clock.schedule_once(lambda dt: self.manager.get_screen("chat").refresh_toolbar(), 0.1)

    def about(self):
        dialog = MDDialog(
            title="Cerberus IA v%s" % VERSION,
            text="Asistente de IA creado por %s.\nContacto: %s\n\n"
                 "Version KivyMD preparada para Android APK." % (AUTHOR, EMAIL),
            buttons=[MDFlatButton(text="Cerrar",
                                  on_release=lambda x: dialog.dismiss())],
        )
        dialog.open()


# ---------------------------------------------------------------------------
# App principal
# ---------------------------------------------------------------------------

class CerberusApp(MDApp):
    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "DeepPurple"

        self.config = load_json("config.json", DEFAULT_CONFIG)
        for k, v in DEFAULT_CONFIG.items():
            self.config.setdefault(k, v)

        self.conversations = load_json(
            "conversations.json",
            {"active_id": None, "chats": {}},
        )
        if "chats" not in self.conversations:
            self.conversations = {"active_id": None, "chats": {}}
        if not self.conversations["chats"]:
            self.new_conversation(save=False)

        # Navegacion: cajon lateral + pantallas
        self.nav_layout = MDNavigationLayout()
        self.sm = MDScreenManager()
        self.chat_screen = ChatScreen(name="chat")
        self.settings_screen = SettingsScreen(name="settings")
        self.sm.add_widget(self.chat_screen)
        self.sm.add_widget(self.settings_screen)

        self.nav_drawer = MDNavigationDrawer()
        drawer_content = MDBoxLayout(orientation="vertical", padding=dp(8), spacing=dp(6))
        drawer_content.add_widget(MDLabel(
            text="Cerberus IA", font_style="H5", adaptive_height=True,
            padding=[dp(16), dp(24), 0, dp(4)],
        ))
        drawer_content.add_widget(MDLabel(
            text="por %s" % AUTHOR, adaptive_height=True,
            theme_text_color="Secondary", padding=[dp(16), 0, 0, dp(12)],
        ))
        new_btn = MDRaisedButton(
            text="Nueva conversacion", icon="plus",
            on_release=lambda x: self.action_new_chat(),
            pos_hint={"center_x": 0.5}, size_hint_x=0.9,
        )
        drawer_content.add_widget(new_btn)

        self.chat_list = MDList()
        drawer_scroll = ScrollView()
        drawer_scroll.add_widget(self.chat_list)
        drawer_content.add_widget(drawer_scroll)

        self.nav_drawer.add_widget(drawer_content)
        self.nav_layout.add_widget(self.sm)
        self.nav_layout.add_widget(self.nav_drawer)

        self.refresh_chat_list()
        self.chat_screen.render_conversation()

        # Boton "atras" de Android
        Window.bind(on_key=self._on_key)
        return self.nav_layout

    # -- conversaciones ---------------------------------------------------
    def current_conversation(self):
        cid = self.conversations["active_id"]
        return self.conversations["chats"].get(cid)

    def new_conversation(self, save=True):
        cid = str(uuid4())[:8]
        self.conversations["chats"][cid] = {
            "title": "Nueva conversacion",
            "created": datetime.now().isoformat(timespec="seconds"),
            "messages": [],
        }
        self.conversations["active_id"] = cid
        if save:
            save_json_atomic("conversations.json", self.conversations)

    def action_new_chat(self):
        self.new_conversation()
        self.refresh_chat_list()
        self.chat_screen.render_conversation()
        self.nav_drawer.set_state("close")

    def delete_conversation(self, cid):
        def confirm(*a):
            dialog.dismiss()
            self.conversations["chats"].pop(cid, None)
            if self.conversations["active_id"] == cid:
                if self.conversations["chats"]:
                    self.conversations["active_id"] = next(iter(self.conversations["chats"]))
                else:
                    self.new_conversation(save=False)
            save_json_atomic("conversations.json", self.conversations)
            self.refresh_chat_list()
            self.chat_screen.render_conversation()

        dialog = MDDialog(
            title="Eliminar conversacion?",
            buttons=[
                MDFlatButton(text="Cancelar", on_release=lambda x: dialog.dismiss()),
                MDFlatButton(text="Eliminar", on_release=confirm),
            ],
        )
        dialog.open()

    def select_conversation(self, cid):
        self.conversations["active_id"] = cid
        save_json_atomic("conversations.json", self.conversations)
        self.chat_screen.render_conversation()
        self.nav_drawer.set_state("close")

    def refresh_chat_list(self):
        self.chat_list.clear_widgets()
        for cid, chat in self.conversations["chats"].items():
            item = OneLineAvatarIconListItem(text=chat.get("title", "Sin titulo"))
            item.bind(on_release=lambda x, c=cid: self.select_conversation(c))
            icon = IconRightWidget(icon="trash-can")
            icon.bind(on_release=lambda x, c=cid: self.delete_conversation(c))
            item.add_widget(icon)
            self.chat_list.add_widget(item)

    # -- tecla atras ------------------------------------------------------
    def _on_key(self, window, key, *args):
        if key == 27:  # ESC / back
            if self.sm.current == "settings":
                self.sm.current = "chat"
                return True
            if self.nav_drawer.state == "open":
                self.nav_drawer.set_state("close")
                return True
        return False


if __name__ == "__main__":
    CerberusApp().run()
