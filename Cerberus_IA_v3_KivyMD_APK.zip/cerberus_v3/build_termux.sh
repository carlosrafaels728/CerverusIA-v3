#!/usr/bin/env bash
# build_termux.sh — Compila Cerberus IA a APK desde Termux (Android)
#
# Metodo: Ubuntu dentro de proot-distro (el unico metodo fiable en Termux,
# porque python-for-android necesita glibc y el NDK de Android).
#
# USO:
#   1. Copia toda esta carpeta a ~/cerberus_v3 en el telefono.
#   2. En Termux:  bash build_termux.sh
#   3. El APK quedara en ~/cerberus_v3/bin/*.apk
#
# Requisitos: ~6 GB libres, Internet estable, paciencia (1a compilacion 1-2 h).
set -e

PROJECT_DIR="$HOME/cerberus_v3"

echo "[1/4] Instalando proot-distro y herramientas basicas..."
pkg update -y
pkg install -y proot-distro git wget curl

echo "[2/4] Instalando Ubuntu (contenedor)..."
proot-distro install ubuntu || true

echo "[3/4] Lanzando compilacion dentro de Ubuntu..."
# --bind monta el proyecto dentro del contenedor
proot-distro login ubuntu --bind "$PROJECT_DIR:/root/cerberus" -- bash /root/cerberus/build_inner.sh

echo "[4/4] Listo. APK(s) generados:"
ls -la "$PROJECT_DIR"/bin/*.apk 2>/dev/null || echo "No se encontro APK. Revisa los logs arriba."
echo "Instala con: pkg install android-tools && adb install $PROJECT_DIR/bin/*.apk"
echo "o copia el .apk al almacenamiento y abrelo."
