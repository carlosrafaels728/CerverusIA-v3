[app]

# Nombre de la app (aparece en el lanzador de Android)
title = Cerberus IA

# Nombre del paquete (minusculas, sin espacios)
package.name = cerberusia

# Dominio inverso del autor
package.domain = org.carlosart

# Codigo fuente
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json,ttf
version = 3.0

# Dependencias (mismas versiones que se probaron)
requirements = python3,kivy==2.3.0,kivymd==1.2.0,pillow

# Orientacion y pantalla
orientation = portrait
fullscreen = 0

# Android SDK / NDK (combinacion estable conocida)
android.api = 33
android.minapi = 21
android.ndk = 25b
android.archs = arm64-v8a

# Permisos
android.permissions = INTERNET, ACCESS_NETWORK_STATE

# Permitir backup y mostrar en pantalla completa reciente
android.allow_backup = True
android.wakelock = False

# Icono y pantalla de carga
icon.filename = %(source.dir)s/icon.png
presplash.filename = %(source.dir)s/presplash.png
presplash.color = #0B1220

# Rama de python-for-android
p4a.branch = master

# No pedir confirmaciones al compilar (ideal para Termux/CI)
build.mode = debug

[buildozer]
log_level = 2
warn_on_root = 1
