import os, sys, tempfile, traceback
os.environ["HOME"] = tempfile.mkdtemp()
sys.path.insert(0, ".")
from kivy.clock import Clock
from main import CerberusApp

app = CerberusApp()
errors = []

def test(dt):
    try:
        cs = app.chat_screen
        assert cs.messages is not None, "sin widget de mensajes"
        n0 = len(cs.messages.children)
        cs.add_bubble("mensaje de prueba", from_user=True, save=True)
        assert len(cs.messages.children) == n0 + 1, "no se anadio burbuja"
        conv = app.current_conversation()
        assert conv["messages"][-1]["text"] == "mensaje de prueba", "no se guardo en historial"
        assert conv["title"] == "mensaje de prueba", "titulo auto no asignado"

        # nueva conversacion
        before = len(app.conversations["chats"])
        app.action_new_chat()
        assert len(app.conversations["chats"]) == before + 1, "new chat fallo"

        # toggle modo
        app.chat_screen.toggle_mode()
        assert app.config["online_mode"] is True, "toggle online fallo"
        app.chat_screen.toggle_mode()

        # ajustes: guardar
        st = app.settings_screen
        st.endpoint.text = "https://api.example.com/chat"
        st.token.text = "secreto123"
        st.online_switch.active = True
        st.save()
        assert app.config["online_endpoint"] == "https://api.example.com/chat", "endpoint no guardado"
        assert app.config["api_token"] == "secreto123", "token no guardado"
        assert app.config["online_mode"] is True, "switch no guardado"

        # endpoint invalido
        st.endpoint.text = "no-es-url"
        st.save()  # debe rechazar con toast, no cambiar
        assert app.config["online_endpoint"] == "https://api.example.com/chat", "endpoint invalido aceptado"

        # eliminar conversacion (sin dialogo: llamamos logica interna)
        cid = app.conversations["active_id"]
        app.conversations["chats"].pop(cid, None)
        if not app.conversations["chats"]:
            app.new_conversation(save=False)
        else:
            app.conversations["active_id"] = next(iter(app.conversations["chats"]))
        app.refresh_chat_list()
        assert len(app.chat_list.children) == len(app.conversations["chats"]), "lista de chats no coincide"

        print("TESTS OK")
    except Exception:
        errors.append(traceback.format_exc())
    finally:
        app.stop()

Clock.schedule_once(test, 0.3)
app.run()
if errors:
    print("ERRORES:")
    for e in errors:
        print(e)
    sys.exit(1)
